<html>
    <title>Home Page </title>

    <head>

        <link rel="stylesheet" href="../../CSS/mainstyles.css" />

    </head>

    <body>
        <?php include '../NavbarFooter/nav.php'; ?>
        <div class="content">
            <h2> Home</h2>

            <p><a href="../adminpages/Contactdata.php">Contact Data </a></p>
            <p><a href="../adminpages/account-login-logs.php">Login Logs</a></p>
        </div>
    </body>

         <?php include '../NavbarFooter/footer.php'; ?>

</html>